//左下のメッセージ
function todo(mes){
	$('#message').text(mes);
	$('#message').fadeIn();
}
function todc(){
	$('#message').fadeOut();
}
